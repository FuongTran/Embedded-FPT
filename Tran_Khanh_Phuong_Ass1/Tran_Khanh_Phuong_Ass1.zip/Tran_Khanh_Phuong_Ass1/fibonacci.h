#ifndef FIBONACCI_H
#define FIBONACCI_H

unsigned long long fibonacci(int n);

#endif /* FIBONACCI_H */